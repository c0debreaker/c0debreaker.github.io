---
layout: home
description: "A responsive Jekyll theme with editorial tendencies by designer Michael Rose."
tags: [Jekyll, theme, responsive, blog, template]
image:
  feature: texture-feature-01.jpg
  credit: Texture Lovers
  creditlink: http://texturelovers.com
---